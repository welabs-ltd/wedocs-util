<div class="wrap">
    <div id="wedocs-app" class='wedocs-document'></div>
</div>
